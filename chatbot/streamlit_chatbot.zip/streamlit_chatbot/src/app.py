from home_page import HomePage

if __name__ == "__main__":
    page = HomePage()
    page.main()